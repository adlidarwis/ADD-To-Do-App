package com.dicoding.todoapp.ui.detail

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.dicoding.todoapp.R
import com.dicoding.todoapp.ui.ViewModelFactory
import com.dicoding.todoapp.utils.DateConverter
import com.google.android.material.textfield.TextInputEditText

class DetailTaskActivity : AppCompatActivity() {

    private lateinit var tvTitle: TextInputEditText
    private lateinit var tvDesc: TextInputEditText
    private lateinit var tvDate: TextInputEditText

    private lateinit var viewModel: DetailTaskViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_detail)

        //TODO 11 : Show detail task and implement delete action

        val factory = ViewModelFactory.getInstance(this)
        viewModel = ViewModelProvider(this, factory).get(DetailTaskViewModel::class.java)

        tvTitle = findViewById(R.id.detail_ed_title)
        tvDesc = findViewById(R.id.detail_ed_description)
        tvDate = findViewById(R.id.detail_ed_due_date)

        val taskId = intent.getIntExtra("TASK_ID", 0)

        viewModel.setTaskId(taskId)

        viewModel.task.observe(this) { task ->
            tvTitle.setText(task?.title)
            tvDesc.setText(task?.description)
            val formattedDate = DateConverter.convertMillisToString(task?.dueDateMillis ?: 0)
            tvDate.setText(formattedDate)
        }

        // Delete action
        val btnDelete = findViewById<Button>(R.id.btn_delete_task)
        btnDelete.setOnClickListener {
            viewModel.deleteTask()
            Toast.makeText(this, "Task deleted", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}

